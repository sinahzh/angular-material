export interface Login {
        userid: string;    
        password: string;    
}
